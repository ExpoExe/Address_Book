<?php
/**
 * Created by PhpStorm.
 * User: Justin_NZXT
 * Date: 3/4/2016
 * Time: 4:52 PM
 */
//DB PARAMS
define('DB_HOST', '155.254.18.31');
define('DB_USER', 'justinri_test');
define('DB_PASS', 'PHPaddress');
define('DB_NAME', 'justinri_addressbook');