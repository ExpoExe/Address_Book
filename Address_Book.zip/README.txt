Welcome to Address Book.

Be sure to change the database credentials in config/config.php to set up your local test environment.
Be sure the SQL user has the permission to CREATE, INSERT, SELECT, DELETE, and EXECUTE at least.

Some sample SQL data was included, but it is not necessary to import it in order to use the application.
Simply load the files onto the server, access index.php, and begin using the application.

A live demo is available at http://address.justinrichardweb.com/

Enjoy.